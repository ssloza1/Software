
const { MongoClient } = require("mongodb");

const client = new MongoClient("mongodb://localhost:27017");
const dbName = "petshopDB";

async function getCollection() {
    await client.connect();
    return client.db(dbName).collection("suppliers");
}

module.exports = { getCollection };
