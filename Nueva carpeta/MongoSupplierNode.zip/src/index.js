
const { getCollection } = require("./db");

async function main() {
    const col = await getCollection();

    await col.insertOne({
        idSupplier: "1",
        name: "Proveedor JS",
        phone: "0888888888",
        address: "Guayaquil"
    });

    const supplier = await col.findOne({ idSupplier: "1" });
    console.log("Proveedor encontrado:", supplier);
}

main();
