
import view.FrmSupplierRegister;

public class Main {
    public static void main(String[] args) {
        new FrmSupplierRegister().setVisible(true);
    }
}
