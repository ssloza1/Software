
package controller;

import com.mongodb.client.MongoCollection;
import db.MongoDBConnection;
import model.Supplier;
import org.bson.Document;
import static com.mongodb.client.model.Filters.eq;

public class SupplierController {

    MongoCollection<Document> col =
            MongoDBConnection.getSupplierCollection();

    public void save(Supplier s) {
        Document doc = new Document("idSupplier", s.getIdSupplier())
                .append("name", s.getName())
                .append("phone", s.getPhone())
                .append("address", s.getAddress());
        col.insertOne(doc);
    }

    public Supplier findById(String id) {
        Document d = col.find(eq("idSupplier", id)).first();
        if (d == null) return null;
        return new Supplier(
                d.getString("idSupplier"),
                d.getString("name"),
                d.getString("phone"),
                d.getString("address")
        );
    }
}
