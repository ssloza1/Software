
package db;

import com.mongodb.client.*;
import org.bson.Document;

public class MongoDBConnection {
    private static MongoClient client;
    private static MongoDatabase database;

    public static MongoDatabase connect() {
        if (database == null) {
            client = MongoClients.create("mongodb://localhost:27017");
            database = client.getDatabase("petshopDB");
        }
        return database;
    }

    public static MongoCollection<Document> getSupplierCollection() {
        return connect().getCollection("suppliers");
    }
}
