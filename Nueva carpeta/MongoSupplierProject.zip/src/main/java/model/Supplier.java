
package model;

public class Supplier {
    private String idSupplier;
    private String name;
    private String phone;
    private String address;

    public Supplier(String idSupplier, String name, String phone, String address) {
        this.idSupplier = idSupplier;
        this.name = name;
        this.phone = phone;
        this.address = address;
    }

    public String getIdSupplier() { return idSupplier; }
    public String getName() { return name; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }
}
