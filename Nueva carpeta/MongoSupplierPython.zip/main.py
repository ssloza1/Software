
from db import get_collection
from model import Supplier

def save_supplier():
    col = get_collection()
    s = Supplier("1", "Proveedor Python", "0999999999", "Quito")
    col.insert_one(s.to_dict())
    print("Proveedor guardado en MongoDB")

def read_supplier():
    col = get_collection()
    doc = col.find_one({"idSupplier": "1"})
    print("Proveedor encontrado:", doc)

if __name__ == "__main__":
    save_supplier()
    read_supplier()
