
class Supplier:
    def __init__(self, idSupplier, name, phone, address):
        self.idSupplier = idSupplier
        self.name = name
        self.phone = phone
        self.address = address

    def to_dict(self):
        return self.__dict__
